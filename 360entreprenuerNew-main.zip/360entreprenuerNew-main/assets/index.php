<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <title>The VR Company</title>

    <meta name="description" content="The VR Company, one of the best content agency based in Mumbai serving across nation. We create content that matters. Drone videos, 3D renders, Virtual Walkthroughs and more. ">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="google-site-verification" content="FzRh0ZWysfn_pwKiuw5GUp2UXxYjmnVCYO3XhbK-dbA" />
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png">

    <!-- CSS Style -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/plugins/feature.css">
    <link rel="stylesheet" href="assets/css/vendor/slick.css">
    <link rel="stylesheet" href="assets/css/vendor/slick-theme.css">
    <link rel="stylesheet" href="assets/css/vendor/lightbox.css">
    <link rel="stylesheet" href="assets/css/vendor/fontawesome.css">
    <link rel="stylesheet" href="assets/css/style.css">




    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-245K5Y8DY7"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'G-245K5Y8DY7');
    </script>


</head>

<body>
    <!-- start header Arae -->
    <header class="header-area formobile-menu header--transparent header--fixed header--sticky default-color">
        <div class="header-wrapper" id="header-wrapper">
            <div class="header-left">
                <div class="logo">
                    <a href="index.php">
                        <img class="logo-1" src="assets/images/logo/logo-vr-white1.png" alt="TheVRCompany">
                        <img class="logo-2" src="assets/images/logo/logo-vr.png" alt="TheVRCompany">
                    </a>
                </div>
            </div>
            <div class="header-right">
                <nav class="mainmenunav d-none d-md-block">
                    <ul class="mainmenu">
                        <li class="has-dropdown">
                            <a href="index.php">Home</a>
                        </li>
                        <li class="has-dropdown">
                            <a href="#">Solutions</a>
                            <ul class="submenu">
                                <li><a href="solutions-location-advantage.php">Location Advantage</a></li>
                                <li><a href="solutions-area-wiki.php">Area Wiki</a></li>
                                <li><a href="solutions-3d-services.php">3D Services</a></li>
                                <li><a href="solutions-hd-photoshoot.php">HD Photoshoot</a></li>
                                <li><a href="solutions-aerial-survey.php">Drone 360</a></li>
                                <li><a href="solutions-drone-survey.php">Drone Survey</a></li>
                                <li><a href="solutions-google-street-view.php">Google Street View</a></li>
                                <li><a href="solutions-virtual-tour.php">Virtual Tour</a></li>
                            </ul>
                        </li>
                        <li class="has-dropdown"><a href="#">Industries</a>
                            <ul class="submenu">
                                <li><a href="industries-real-estate.php">Real Estate</a></li>
                                <!-- <li><a href="industries-lifestyle.php">Lifestyle</a></li> -->
                                <li><a href="industries-hospitality.php">Hospitality</a></li>
                                <!-- <li><a href="industries-education.php">Education</a></li> -->
                                <li><a href="industries-medical.php">Medical</a></li>
                            </ul>
                        </li>
                        <li><a href="clients.php">Clients</a></li>
                        <li><a href="work-with-us.php">Fly With Us</a></li>
                        <li><a href="careers.php">Careers</a></li>
                        <li><a href="blogs.php">Blogs</a></li>
                        <li><a href="about.php">About Us</a></li>
                    </ul>
                </nav>
                <div class="header-btn">
                    <a class="btn-default btn-border btn-opacity" href="contact.php">
                        <span>Contact Us</span>
                    </a>
                </div>
                <div class="humberger-menu d-block d-lg-none pl--20 pl_sm--10">
                    <span class="menutrigger text-white">
                        <i data-feather="menu"></i>
                    </span>
                </div>
            </div>
        </div>
    </header>
    <!-- End header Area -->
    <!-- Start Popup Menu Area  -->
    <div class="rn-popup-mobile-menu d-block d-lg-none">
        <div class="inner">
            <div class="popup-menu-top">
                <div class="logo">
                    <a href="index.php"><img src="assets/images/logo/logo-vr.png" alt="vrcompany"></a>
                </div>
                <div class="close-menu d-block d-lg-none">
                    <span class="closeTrigger">
                    <i data-feather="x"></i>
                </span>
                </div>
            </div>
            <ul class="mainmenu">
                <li class="has-dropdown">
                    <a href="index.php">Home</a>
                </li>
                <li class="has-dropdown">
                    <a href="#">Solutions</a>
                    <ul class="submenu">
                        <li><a href="solutions-location-advantage.php">Location Advantage</a></li>
                        <li><a href="solutions-area-wiki.php">Area Wiki</a></li>
                        <li><a href="solutions-3d-services.php">3D Services</a></li>
                        <li><a href="solutions-hd-photoshoot.php">HD Photoshoot</a></li>
                        <li><a href="solutions-aerial-survey.php">Drone 360</a></li>
                        <li><a href="solutions-google-street-view.php">Google Street View</a></li>
                        <li><a href="solutions-virtual-tour.php">Virtual Tour</a></li>
                    </ul>
                </li>
                <li class="has-dropdown"><a href="#">Industries</a>
                    <ul class="submenu">
                        <li><a href="industries-real-estate.php">Real Estate</a></li>
                        <!-- <li><a href="industries-lifestyle.php">Lifestyle</a></li> -->
                        <li><a href="industries-hospitality.php">Hospitality</a></li>
                        <!-- <li><a href="industries-education.php">Education</a></li> -->
                        <li><a href="industries-medical.php">Medical</a></li>
                    </ul>
                </li>
                <li><a href="clients.php">Clients</a></li>
                <li><a href="work-with-us.php">Fly With Us</a></li>
                <li><a href="careers.php">Careers</a></li>
                <li><a href="blogs.php">Blogs</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="contact.php">Contact Us</a></li>
            </ul>
        </div>
    </div>
    <!-- End Popup Menu Area  -->
    <!-- Start Slider Area -->
    <div class="slider-wrapper">
        <div class="slide slide-style-2 slider-video-bg d-flex align-items-center justify-content-center" data-black-overlay="6">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <div class="inner pt_sm--40 text-center"><span class="theme-color font-700">We Make</span>
                            <h1 class="title mt--20">CONTENT THAT MATTERS</h1>
                            <a class="btn-default btn-large mt--30" href="contact.php"><span>Connect Now</span></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="video-background">
                <span>
                    <video muted="" autoplay="" playsinline="" loop="" poster="#">
                                                <source src="assets/images/service/video5.mp4">
                    </video>
                </span>
            </div>
        </div>
        <div class="video-image-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <div class="thumb position-relative"><img class="w-100" src="assets/images/service/home-vid1.jpg" alt="Service Images">
                            <a href="https://youtu.be/WjVJb8WAj24?si=xOa0x0Sfyv9-Ywk6" class="play__btn video-popup position-top-center theme-color"><span class="play-icon"></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Slider Area -->

    <!-- Start p[ortfolio area -->
    <div class="portfolio-area ptb--80 bg_color--1">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title text-center"><span class="subtitle">Our Portfolio</span>
                        <h2 class="title">Everything at a glance</h2>
                    </div>
                </div>
            </div>
            <div class="row rn-slick-activation rn-slick-dot mt--30" data-slick-options='{
                "spaceBetween": 15, 
                "slidesToShow": 3, 
                "slidesToScroll": 1, 
                "arrows": false, 
                "infinite": true,
                "dots": true
                }' data-slick-responsive='[
                {"breakpoint":890, "settings": {"slidesToShow": 3}},
                {"breakpoint":770, "settings": {"slidesToShow": 2}},
                {"breakpoint":490, "settings": {"slidesToShow": 1}}
                ]'>
                <div class="single_im_portfolio">
                    <div class="im_portfolio">
                        <div class="thumbnail_inner">
                            <div class="thumbnail">
                                <a href="https://youtu.be/KgY0B1sYVpQ">
                                    <img src="assets/images/portfolio/solutions/3d/Jasdan_Classic.jpg" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="content">
                            <div class="inner">
                                <div class="portfolio_heading">
                                    <div class="category_list"><a href="https://youtu.be/KgY0B1sYVpQ">Location Advantage</a>
                                    </div>
                                    <h4 class="title"><a href="https://youtu.be/KgY0B1sYVpQ">Prestige - Jasdan Classic</a></h4>
                                </div>
                            </div>
                        </div>
                        <a class="play__btn video-popup position-top-center" href="https://youtu.be/KgY0B1sYVpQ" style="z-index: 9999;"></a>
                    </div>
                </div>
                <div class="single_im_portfolio">
                    <div class="im_portfolio">
                        <div class="thumbnail_inner">
                            <div class="thumbnail"><a href="https://youtu.be/6XW9q7Y0RzQ" target="_blank">
                                <img src="assets/images/portfolio/solutions/3d/kalpataru.jpg" alt=""></a></div>
                        </div>
                        <div class="content">
                            <div class="inner">
                                <div class="portfolio_heading">
                                    <div class="category_list"><a href="https://youtu.be/6XW9q7Y0RzQ" target="_blank">Virtual Tour</a></div>
                                    <h4 class="title">Kalpataru Shrishti</h4>
                                </div>
                            </div>
                        </div><a class="transparent_link" href="https://youtu.be/6XW9q7Y0RzQ" target="_blank"></a>
                    </div>
                </div>
                <div class="single_im_portfolio">
                    <div class="im_portfolio">
                        <div class="thumbnail_inner">
                            <div class="thumbnail">
                                <a href="https://youtu.be/tP8dqNpwKfo">
                                    <img src="assets/images/portfolio/solutions/location-advantage/salsette.jpg" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="content">
                            <div class="inner">
                                <div class="portfolio_heading">
                                    <div class="category_list"><a href="https://youtu.be/tP8dqNpwKfo">Location Advantage</a>
                                    </div>
                                    <h4 class="title"><a href="https://youtu.be/tP8dqNpwKfo">Peninsula Salsette 27</a></h4>
                                </div>
                            </div>
                        </div>
                        <a class="play__btn video-popup position-top-center" href="https://youtu.be/tP8dqNpwKfo" style="z-index: 9999;"></a>
                    </div>
                </div>
                <div class="single_im_portfolio">
                    <div class="im_portfolio">
                        <div class="thumbnail_inner">
                            <div class="thumbnail">
                                <a href="https://youtu.be/382IA0PXV1A">
                                    <img src="assets/images/portfolio/solutions/location-advantage/Bhumi_World.jpg" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="content">
                            <div class="inner">
                                <div class="portfolio_heading">
                                    <div class="category_list"><a href="https://youtu.be/382IA0PXV1A">Location Advantage</a>
                                    </div>
                                    <h4 class="title"><a href="https://youtu.be/382IA0PXV1A">Bhumi World</a></h4>
                                </div>
                            </div>
                        </div>
                        <a class="play__btn video-popup position-top-center" href="https://youtu.be/382IA0PXV1A" style="z-index: 9999;"></a>
                    </div>
                </div>
                <div class="single_im_portfolio">
                    <div class="im_portfolio">
                        <div class="thumbnail_inner">
                            <div class="thumbnail">
                                <a href="https://youtu.be/spEI7ky-WS8">
                                    <img src="assets/images/portfolio/solutions/location-advantage/runwal-25.jpg" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="content">
                            <div class="inner">
                                <div class="portfolio_heading">
                                    <div class="category_list"><a href="https://youtu.be/spEI7ky-WS8">Location Advantage</a>
                                    </div>
                                    <h4 class="title"><a href="https://youtu.be/spEI7ky-WS8">Runwal 25 Hour Life</a></h4>
                                </div>
                            </div>
                        </div>
                        <a class="play__btn video-popup position-top-center" href="https://youtu.be/spEI7ky-WS8" style="z-index: 9999;"></a>
                    </div>
                </div>
                <div class="single_im_portfolio">
                    <div class="im_portfolio">
                        <div class="thumbnail_inner">
                            <div class="thumbnail">
                                <a href="https://youtu.be/vm3Sl4c307Q">
                                    <img src="assets/images/portfolio/solutions/location-advantage/Mahindra Meridian.jpg" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="content">
                            <div class="inner">
                                <div class="portfolio_heading">
                                    <div class="category_list"><a href="https://youtu.be/vm3Sl4c307Q">Location Advantage</a>
                                    </div>
                                    <h4 class="title"><a href="https://youtu.be/vm3Sl4c307Q">Mahindra Meridian</a></h4>
                                </div>
                            </div>
                        </div>
                        <a class="play__btn video-popup position-top-center" href="https://youtu.be/vm3Sl4c307Q" style="z-index: 9999;"></a>
                    </div>
                </div>
                <div class="single_im_portfolio">
                    <div class="im_portfolio">
                        <div class="thumbnail_inner">
                            <div class="thumbnail"><a href="https://thevrcompany.in/demo/Tata-Myst/" target="_blank">
                                <img src="assets/images/portfolio/solutions/drone/tata-myst.jpg" alt=""></a></div>
                        </div>
                        <div class="content">
                            <div class="inner">
                                <div class="portfolio_heading">
                                    <div class="category_list"><a href="https://thevrcompany.in/demo/Tata-Myst/" target="_blank">Drone 360</a></div>
                                    <h4 class="title">TATA Myst</h4>
                                </div>
                            </div>
                        </div><a class="transparent_link" href="https://thevrcompany.in/demo/Tata-Myst/" target="_blank"></a>
                    </div>
                </div>
                <div class="single_im_portfolio">
                    <div class="im_portfolio">
                        <div class="thumbnail_inner">
                            <div class="thumbnail">
                                <a href="https://youtu.be/BQCNmyJBMcY">
                                    <img src="assets/images/portfolio/solutions/location-advantage/Maha Lottery.jpg" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="content">
                            <div class="inner">
                                <div class="portfolio_heading">
                                    <div class="category_list"><a href="https://youtu.be/BQCNmyJBMcY">Location Advantage</a>
                                    </div>
                                    <h4 class="title"><a href="https://youtu.be/BQCNmyJBMcY">Maha Mumbai</a></h4>
                                </div>
                            </div>
                        </div>
                        <a class="play__btn video-popup position-top-center" href="https://youtu.be/BQCNmyJBMcY" style="z-index: 9999;"></a>
                    </div>
                </div>
                <div class="single_im_portfolio">
                    <div class="im_portfolio">
                        <div class="thumbnail_inner">
                            <div class="thumbnail">
                                <a href="https://youtu.be/bJ9N_TVOwsc">
                                    <img src="assets/images/portfolio/solutions/area-wiki/mchi.jpg" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="content">
                            <div class="inner">
                                <div class="portfolio_heading">
                                    <div class="category_list"><a href="https://youtu.be/bJ9N_TVOwsc">Area Wiki</a>
                                    </div>
                                    <h4 class="title"><a href="https://youtu.be/bJ9N_TVOwsc">MCHI Thane</a></h4>
                                </div>
                            </div>
                        </div>
                        <a class="play__btn video-popup position-top-center" href="https://youtu.be/bJ9N_TVOwsc" style="z-index: 9999;"></a>
                    </div>
                </div>
                <div class="single_im_portfolio">
                    <div class="im_portfolio">
                        <div class="thumbnail_inner">
                            <div class="thumbnail">
                                <a href="https://youtu.be/HKcLzPuDjqw">
                                    <img src="assets/images/portfolio/solutions/location-advantage/Prescon_Midtown_bay.jpg" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="content">
                            <div class="inner">
                                <div class="portfolio_heading">
                                    <div class="category_list"><a href="https://youtu.be/HKcLzPuDjqw">Location Advantage</a>
                                    </div>
                                    <h4 class="title"><a href="https://youtu.be/HKcLzPuDjqw">Midtown Bay</a></h4>
                                </div>
                            </div>
                        </div>
                        <a class="play__btn video-popup position-top-center" href="https://youtu.be/HKcLzPuDjqw" style="z-index: 9999;"></a>
                    </div>
                </div>
                <div class="single_im_portfolio">
                    <div class="im_portfolio">
                        <div class="thumbnail_inner">
                            <div class="thumbnail">
                                <a href="https://youtu.be/wqVqdRMyhic">
                                    <img src="assets/images/portfolio/solutions/location-advantage/koltepatil.jpg" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="content">
                            <div class="inner">
                                <div class="portfolio_heading">
                                    <div class="category_list"><a href="https://youtu.be/wqVqdRMyhic">Location Advantage</a>
                                    </div>
                                    <h4 class="title"><a href="https://youtu.be/wqVqdRMyhic">Kolte Patil</a></h4>
                                </div>
                            </div>
                        </div>
                        <a class="play__btn video-popup position-top-center" href="https://youtu.be/wqVqdRMyhic" style="z-index: 9999;"></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- En p[ortfolio area -->

    <!-- Start Services Area -->
    <div class="service-area ptb--80 bg_color--2">
        <div class="container">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-title text-center"><span class="text-white">What we can do for you</span>
                            <h2 class="title">Services we provide</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12 col-12">
                        <div class="row service-main-wrapper justify-content-center">
                            <div class="col-lg-4 col-md-4 col-sm-6 col-12">
                                <a href="solutions-location-advantage.php">
                                    <div class="service service__style--2 text-left">
                                        <div class="icon">
                                            <i data-feather="map-pin"></i>
                                        </div>
                                        <div class="content">
                                            <h3 class="title">Location Advantage</h3>
                                            <p>Highlight every aspect of your property like amenities, ease of connectivity and much more</p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-6 col-12">
                                <a href="solutions-area-wiki.php">
                                    <div class="service service__style--2 text-left">
                                        <div class="icon">
                                            <i data-feather="map"></i>
                                        </div>
                                        <div class="content">
                                            <h3 class="title">Area Wiki</h3>
                                            <p>In depth information of your project is delivered right with Area Wiki.</p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-6 col-12">
                                <a href="solutions-3d-services.php">
                                    <div class="service service__style--2 text-left">
                                        <div class="icon">
                                            <i data-feather="layers"></i>
                                        </div>
                                        <div class="content">
                                            <h3 class="title">3D Services</h3>
                                            <p>Technology featured in Google Maps & Earth. Street View provides panoramic views.</p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <!-- <div class="col-lg-3 col-md-4 col-sm-6 col-12">
                                <a href="solutions-hd-photoshoot.php">
                                    <div class="service service__style--2 text-left">
                                        <div class="icon">
                                            <i data-feather="camera"></i>
                                        </div>
                                        <div class="content">
                                            <h3 class="title">HD Photoshoot</h3>
                                            <p>Show every detail of the property even before it is constructed through a detailed 360 Virtual Tour.</p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-lg-3 col-md-4 col-sm-6 col-12">
                                <a href="solutions-hd-videoshoot.php">
                                    <div class="service service__style--2 text-left">
                                        <div class="icon">
                                            <i data-feather="video"></i>
                                        </div>
                                        <div class="content">
                                            <h3 class="title">HD Videoshoot</h3>
                                            <p>Drone video allow you to open a new perspective for your customer. Drone video is a easier solution.</p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-lg-3 col-md-4 col-sm-6 col-12">
                                <a href="solutions-aerial-survey.php">
                                    <div class="service service__style--2 text-left">
                                        <div class="icon">
                                            <i data-feather="info"></i>
                                        </div>
                                        <div class="content">
                                            <h3 class="title">Aerial Survey</h3>
                                            <p>Using drones that provide highly valuable information like boundary lines, topographic contours, ETC.</p>
                                        </div>
                                    </div>
                                </a>
                            </div> -->
                            <div class="col-lg-4 col-md-4 col-sm-6 col-12">
                                <a href="solutions-google-street-view.php">
                                    <div class="service service__style--2 text-left">
                                        <div class="icon">
                                            <i data-feather="user"></i>
                                        </div>
                                        <div class="content">
                                            <h3 class="title">Google Street View</h3>
                                            <p>Technology featured in Google Maps & Earth. Street View provides panoramic views.</p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-6 col-12">
                                <a href="solutions-virtual-tour.php">
                                    <div class="service service__style--2 text-left">
                                        <div class="icon">
                                            <i data-feather="airplay"></i>
                                        </div>
                                        <div class="content">
                                            <h3 class="title">Virtual Tour</h3>
                                            <p>Show every detail of the property even before it is constructed through a detailed 360 Virtual Tour.</p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Services Area -->

    <!-- About Area Start -->
    <div class="about-area ptb--80 bg_color--1">
        <div class="about-wrapper">
            <div class="container">
                <div class="row row--20 align-items-center">
                    <div class="col-lg-6 col-md-12">
                        <div class="thumbnail"><img class="w-100" src="assets/images/about/about-3.jpg" alt="About Images"></div>
                    </div>
                    <div class="col-lg-6 col-md-12">
                        <div class="about-inner inner">
                            <div class="section-title"><span class="subtitle">About Us</span>
                                <h2 class="title">A Content Agency Like No Other!</h2>
                                <p class="description">The VR Company, one of the best Drone Agency in Mumbai serving across nation. We create content that matters. Drone videos, 3D renders, Virtual Walkthroughs and Drone 360 and much more for Retail and Real-Estate.
                                </p>
                            </div>
                            <div class="row">
                                <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                                    <div class="about-us-list">
                                        <h5 class="title">Innovate & Integrate</h5>
                                        <p>Cutting edge tech produces high end renders that reimagines your brand.</p>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                                    <div class="about-us-list">
                                        <h5 class="title">Visualize your space</h5>
                                        <p>Imagine taking your favorite interior design ideas & seeing them in an actual room.</p>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                                    <div class="about-us-list">
                                        <h5 class="title">Precision</h5>
                                        <p>We employ the best resources to perfectly & precisely transform your ideas.</p>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                                    <div class="about-us-list">
                                        <h5 class="title">Quality</h5>
                                        <p>We always deliver to the best of our ability and work on projects where quality is given priority over the cost.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="purchase-btn mt--50"><a class="btn-transparent" href="about.php">KNOW MORE</a></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About Area End -->

    <!-- Counter Up Area Start -->
    <div class="rn-counterup-area ptb--80 bg_color--4">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title text-center"><span class="subtitle">Achievements</span>
                        <h2 class="title text-white">Our Company Growth</h2>
                    </div>
                </div>
            </div>
            <div class="row mt--30">
                <div class="im_single_counterup col-lg-3 col-md-4 col-sm-6 col-12">
                    <div class="im_counterup">
                        <div class="inner">
                            <div class="icon">
                                <i data-feather="video"></i>
                            </div>
                            <h2 class="counter"><span>3000</span></h2>
                            <p class="description">Drone Shoot</p>
                        </div>
                    </div>
                </div>
                <div class="im_single_counterup col-lg-3 col-md-4 col-sm-6 col-12">
                    <div class="im_counterup">
                        <div class="inner">
                            <div class="icon">
                                <i data-feather="camera"></i>
                            </div>
                            <h2 class="counter"><span>100</span></h2>
                            <p class="description">Photographer + Pilots</p>
                        </div>
                    </div>
                </div>
                <div class="im_single_counterup col-lg-3 col-md-4 col-sm-6 col-12">
                    <div class="im_counterup">
                        <div class="inner">
                            <div class="icon">
                                <i data-feather="map-pin"></i>
                            </div>
                            <h2 class="counter"><span>5000</span></h2>
                            <p class="description">Google Street View</p>
                        </div>
                    </div>
                </div>
                <div class="im_single_counterup col-lg-3 col-md-4 col-sm-6 col-12">
                    <div class="im_counterup">
                        <div class="inner">
                            <div class="icon">
                                <i data-feather="award"></i>
                            </div>
                            <h2 class="counter"><span>12</span></h2>
                            <p class="description">Awards</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Counter Up Area End -->

    <!-- Start Testimonial area -->
    <!-- <div class="rn-testimonial-area bg_color--1 ptb--80">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="rn-testimonial-content tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="tab1" role="tabpanel" aria-labelledby="tab1-tab">
                            <div class="inner">
                                <p>Aklima The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                    below for those interested. Sections Bonorum et Malorum original.</p>
                            </div>
                            <div class="author-info">
                                <h6><span>Fatima Asrafy </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab2" role="tabpanel" aria-labelledby="tab2-tab">
                            <div class="inner">
                                <p>Aklima The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                    below for those interested. Sections Bonorum et Malorum original.</p>
                            </div>
                            <div class="author-info">
                                <h6><span>Fatima Asrafy </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab3" role="tabpanel" aria-labelledby="tab3-tab">
                            <div class="inner">
                                <p>Aklima The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                    below for those interested. Sections Bonorum et Malorum original.</p>
                            </div>
                            <div class="author-info">
                                <h6><span>Fatima Asrafy </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab4" role="tabpanel" aria-labelledby="tab4-tab">
                            <div class="inner">
                                <p>Aklima The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                    below for those interested. Sections Bonorum et Malorum original.</p>
                            </div>
                            <div class="author-info">
                                <h6><span>Fatima Asrafy </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab5" role="tabpanel" aria-labelledby="tab5-tab">
                            <div class="inner">
                                <p>Aklima The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                    below for those interested. Sections Bonorum et Malorum original.</p>
                            </div>
                            <div class="author-info">
                                <h6><span>Fatima Asrafy </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab6" role="tabpanel" aria-labelledby="tab6-tab">
                            <div class="inner">
                                <p>Aklima The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                    below for those interested. Sections Bonorum et Malorum original.</p>
                            </div>
                            <div class="author-info">
                                <h6><span>Fatima Asrafy </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab7" role="tabpanel" aria-labelledby="tab7-tab">
                            <div class="inner">
                                <p>Aklima The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                    below for those interested. Sections Bonorum et Malorum original.</p>
                            </div>
                            <div class="author-info">
                                <h6><span>Fatima Asrafy </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab8" role="tabpanel" aria-labelledby="tab8-tab">
                            <div class="inner">
                                <p>Aklima The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                    below for those interested. Sections Bonorum et Malorum original.</p>
                            </div>
                            <div class="author-info">
                                <h6><span>Fatima Asrafy </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 mt_md--40 mt_sm--40">
                    <ul class="testimonial-thumb-wrapper nav nav-tabs" id="myTab" role="tablist">
                        <li>
                            <a class="active" id="tab1-tab" data-toggle="tab" href="#tab1" role="tab" aria-controls="tab1" aria-selected="true">
                                <div class="testimonial-thumbnai">
                                    <div class="thumb">
                                        <img src="assets/images/client/testimonial-1.jpg" alt="Testimonial Images">
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a id="tab2-tab" data-toggle="tab" href="#tab2" role="tab" aria-controls="tab2" aria-selected="false">
                                <div class="testimonial-thumbnai">
                                    <div class="thumb">
                                        <img src="assets/images/client/testimonial-2.jpg" alt="Testimonial Images">
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a id="tab3-tab" data-toggle="tab" href="#tab3" role="tab" aria-controls="tab3" aria-selected="false">
                                <div class="testimonial-thumbnai">
                                    <div class="thumb">
                                        <img src="assets/images/client/testimonial-3.jpg" alt="Testimonial Images">
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a id="tab4-tab" data-toggle="tab" href="#tab4" role="tab" aria-controls="tab4" aria-selected="false">
                                <div class="testimonial-thumbnai">
                                    <div class="thumb">
                                        <img src="assets/images/client/testimonial-4.jpg" alt="Testimonial Images">
                                    </div>
                                </div>
                            </a>
                        </li>

                        <li>
                            <a id="tab5-tab" data-toggle="tab" href="#tab5" role="tab" aria-controls="tab5" aria-selected="false">
                                <div class="testimonial-thumbnai">
                                    <div class="thumb">
                                        <img src="assets/images/client/testimonial-5.jpg" alt="Testimonial Images">
                                    </div>
                                </div>
                            </a>
                        </li>

                        <li>
                            <a id="tab6-tab" data-toggle="tab" href="#tab6" role="tab" aria-controls="tab6" aria-selected="false">
                                <div class="testimonial-thumbnai">
                                    <div class="thumb">
                                        <img src="assets/images/client/testimonial-6.jpg" alt="Testimonial Images">
                                    </div>
                                </div>
                            </a>
                        </li>

                        <li>
                            <a id="tab7-tab" data-toggle="tab" href="#tab7" role="tab" aria-controls="tab7" aria-selected="false">
                                <div class="testimonial-thumbnai">
                                    <div class="thumb">
                                        <img src="assets/images/client/testimonial-7.jpg" alt="Testimonial Images">
                                    </div>
                                </div>
                            </a>
                        </li>

                        <li>
                            <a id="tab8-tab" data-toggle="tab" href="#tab8" role="tab" aria-controls="tab8" aria-selected="false">
                                <div class="testimonial-thumbnai">
                                    <div class="thumb">
                                        <img src="assets/images/client/testimonial-8.jpg" alt="Testimonial Images">
                                    </div>
                                </div>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div> -->
    <!-- End TEstimonial area -->

    <!-- Start Brand Area -->
    <div class="rn-brand-area bg_color--5 ptb--80">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="section-title text-center mb--30"><span class="subtitle">Top clients</span>
                        <h2 class="title">Few names whom we served</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <ul class="brand-style-2">
                        <li><img src="assets/images/brand/oberoi.png" alt="oberoi"></li>
                        <li><img src="assets/images/brand/harley.png" alt="harley davidson"></li>
                        <li><img src="assets/images/brand/koltepatil.png" alt="koltepatil"></li>
                        <li><img src="assets/images/brand/hiranandani.png" alt="hiranandani"></li>
                        <li><img src="assets/images/brand/tatahousing.png" alt="tata"></li>
                        <li><img src="assets/images/brand/piramal.png" alt="piramal"></li>
                        <li><img src="assets/images/brand/citroen.png" alt="citroen"></li>
                        <li><img src="assets/images/brand/shapoorjipalonji.png" alt="shapoorjipalonji"></li>
                        <li><img src="assets/images/brand/jackjones.png" alt="jack&jones"></li>
                    </ul>
                    <ul class="brand-style-2">
                        <li><img src="assets/images/brand/orra.png" alt="orra"></li>
                        <li><img src="assets/images/brand/clubmahindra.png" alt="clubmahindra"></li>
                        <li><img src="assets/images/brand/nexa.png" alt="nexa"></li>
                        <li><img src="assets/images/brand/Mahindra_Lifespaces.png" alt="MahindraLifespaces"></li>
                        <li><img src="assets/images/brand/Anarock.png" alt="Anarock"></li>
                        <li><img src="assets/images/brand/Prestige.png" alt="Prestige"></li>
                        <li><img src="assets/images/brand/Godrej.png" alt="Godrej Properties"></li>
                        <li><img src="assets/images/brand/pvr.png" alt="PVR Cinemas"></li>
                        <li><img src="assets/images/brand/Adani.png" alt="Adani realty"></li>


                    </ul>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="purchase-btn mt--50"><a class="btn-transparent" href="clients.php">VIEW MORE</a></div>
            </div>
        </div>
    </div>
    <!-- End Brand Area -->

    <!-- Instagram Widget Start -->
    <div class="about-area ptb--80 bg_color--1">
        <div class="about-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="section-title text-center mb--30">
                            <h2 class="title">Instagram Feed</h2>
                        </div>
                    </div>
                </div>
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <iframe src="https://widget.tagembed.com/76997?view" style=" width:100%;height:300px;overflow: auto;" frameborder="0" allowtransparency="true"></iframe>
                    </div>
                    <div class="col-lg-12 text-center">
                        <div class="purchase-btn mt--50"><a class="btn-transparent" href="https://www.instagram.com/the_vr_company/" target="_blank">SHOW MORE</a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Instagram Widget End -->

    <!-- start footer area -->
    <footer class="footer-area footer-style-01 bg_color--6">
        <div class="footer-wrapper ptb--70 im-separator">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-3 col-xl-3 col-md-3 col-sm-6 col-12 mt_mobile--40">
                        <div class="footer-link">
                            <h4>Quick Links</h4>
                            <ul class="ft-link">
                                <li>
                                    <a href="index.php">Home</a>
                                </li>
                                <li>
                                    <a href="about.php">About us</a>
                                </li>
                                <li>
                                    <a href="clients.php">Clients</a>
                                </li>
                                <li>
                                    <a href="careers.php">Career</a>
                                </li>
                                <li>
                                    <a href="blogs.php">Blogs</a>
                                </li>
                                <li>
                                    <a href="work-with-us.php">Fly with us</a>
                                </li>
                                <li>
                                    <a href="contact.php">Contact us</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-xl-3 col-md-3 col-sm-6 col-12 mt_mobile--40">
                        <div class="footer-link">
                            <h4>Solutions</h4>
                            <ul class="ft-link">
                                <li>
                                    <a href="solutions-area-wiki.php">Area Wiki Video</a>
                                </li>
                                <li>
                                    <a href="solutions-location-advantage.php">Location Advantage Video</a>
                                </li>
                                <li>
                                    <a href="solutions-virtual-tour.php">Virtual Tour</a>
                                </li>
                                <li>
                                    <a href="solutions-aerial-survey.php">Drone 360</a>
                                </li>
                                <li>
                                    <a href="solutions-drone-survey.php">Drone Survey</a>
                                </li>
                                <li>
                                    <a href="solutions-google-street-view.php">GSV</a>
                                </li>
                                <li>
                                    <a href="solutions-hd-photoshoot.php">HD photoshoot</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-xl-3 col-md-3 col-sm-6 col-12 mt_mobile--40">
                        <div class="footer-link">
                            <h4>3D Solutions</h4>
                            <ul class="ft-link">
                                <li>
                                    <a href="solutions-3d-services.php">3D Virtual Tour</a>
                                </li>
                                <li>
                                    <a href="solutions-3d-services.php">3D Superimposition</a>
                                </li>
                                <li>
                                    <a href="solutions-3d-services.php">3D Walkthrough</a>
                                </li>
                                <li>
                                    <a href="solutions-3d-services.php">3D Renders</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-xl-3 col-md-3 col-sm-6 col-12 mt_mobile--40">
                        <div class="footer-link">
                            <h4>Industries</h4>
                            <ul class="ft-link">
                                <li>
                                    <a href="industries-real-estate.php">Real Estate</a>
                                </li>
                                <!-- <li>
                                    <a href="indus">Retail</a>
                                </li> -->
                                <li>
                                    <a href="industries-hospitality.php">Hospitality</a>
                                </li>
                                <li>
                                    <a href="industries-medical.php">Medical</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- End footer area -->


    <div class="footer-style-2 ptb--30 bg_color--6">
        <div class="wrapper plr--50 plr_sm--20">
            <div class="row align-items-center justify-content-between">
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="inner">
                        <div class="text-center text-sm-left mb_sm--20">
                            <p>Copyright © 2022. All Rights Reserved.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                    <div class="inner text-center">
                        <ul class="social-share rn-lg-size d-flex justify-content-center liststyle">
                            <li><a href="https://www.facebook.com/TheVRCompany.in/" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="https://youtube.com/c/TheVRCompany" target="_blank"><i class="fab fa-youtube"></i></a></li>
                            <li><a href="https://www.instagram.com/the_vr_company/" target="_blank"><i class="fab fa-instagram"></i></a></li>
                            <li><a href="https://mobile.twitter.com/thevr_Company" target="_blank"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="https://www.linkedin.com/company/thevrcompany" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-12 col-sm-12 col-12">
                    <div class="inner text-lg-right text-center mt_md--20 mt_sm--20">
                        <div class="text">
                            <p>Made with <i class="fa fa-heart"></i> by <a href="https://botree.in" target="_blank">Botree</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Start Back To Top Start -->
    <!-- Start Top To Bottom Area  -->
    <div class="rn-progress-parent">
        <svg class="rn-back-circle svg-inner" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
        </svg>
    </div>
    <!-- End Top To Bottom Area  -->


    <nav class="socialicons">
        <ul>
            <li>
                <a href="tel:+91 98198 77066" target="_blank" class="linkedin">
                    <span class="social-icon"><i class="fa fa-phone" aria-hidden="true"></i></span>
                </a>
            </li>
        </ul>
    </nav>

    <!-- js  ======================================-->
    <!-- modernizer JS -->
    <script src="assets/js/vendor/modernizer.min.js"></script>
    <!-- jquery JS -->
    <script src="assets/js/vendor/jquery.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.min.js"></script>

    <script src="assets/js/vendor/avoid-console.js"></script>
    <script src="assets/js/vendor/jquery.validate.min.js"></script>
    <script src="assets/js/vendor/waypoint.js"></script>
    <script src="assets/js/vendor/wow.js"></script>
    <script src="assets/js/vendor/feather.js"></script>
    <script src="assets/js/vendor/slick.min.js"></script>
    <script src="assets/js/vendor/counterup.js"></script>
    <script src="assets/js/vendor/video.js"></script>
    <script src="assets/js/vendor/masonry.js"></script>
    <script src="assets/js/vendor/lightbox.js"></script>
    <script src="assets/js/vendor/particles.js"></script>
    <script src="assets/js/vendor/backtotop.js"></script>

    <!-- main JS -->
    <script src="assets/js/main.js"></script>

</body>

</html>