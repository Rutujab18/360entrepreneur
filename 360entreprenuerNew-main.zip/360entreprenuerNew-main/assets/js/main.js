/*------------------------------------------------
Template Name: Imroz - Html5 Agency & Portfolio Template
All Main Js Here  

Index All JS 
-----------------------
        01. Wow Active
        02. Counter Up
        03. Feature Icon Activation
        04. Youtub Popup 
        05. Slick Activation            
        06. Paralax Window
        07. LightBox
        08. Parallax Activation
        09. Masonry Activation
        10. ScrollUp Activation
        11. Mobile Menu Activation
        12. Smoth Scroll
--------------------------------------------------*/

(function(window, document, $, undefined) {
    'use strict';

    var imJs = {

        m: function(e) {
            imJs.d();
            imJs.methods();
        },

        d: function(e) {
            this._window = $(window),
                this._document = $(document),
                this._body = $('body'),
                this._html = $('html')

        },

        methods: function(e) {
            imJs.featherAtcivation();
            imJs.wowActive();
            imJs.counterupActive();
            imJs.videoActivation();
            imJs.slickActivation();
            imJs.mesonaryActivation();
            imJs.lightboxActivation();
            imJs.mobileMenuActive();
            imJs.stickyHeader();
            imJs.contactFo();
            imJs.careerFo();
        },


        contactFo: function() {
            var contactForm = $('#contact-form');
            if (contactForm.length) {
                contactForm.validate({
                    // initialize the plugin
                    rules: {
                        contact_name: {
                            required: true,
                        },
                        contact_email: {
                            required: true,
                            email: true,
                        },
                        contact_phone: {
                            required: true,
                            digits: true,
                            minlength: 10,
                            maxlength: 10,
                        },
                        select_industry: {
                            required: true,
                        },
                        select_solution: {
                            required: true,
                        },
                        contact_message: {
                            required: true,
                        },
                    },
                    messages: {
                        contact_name: {
                            required: "Please enter your name",
                        },
                        contact_email: {
                            required: "Please enter your email",
                            email: "Please enter vaild email",
                        },
                        contact_phone: {
                            required: "Please enter your contact",
                            digits: "Please enter only numbers",
                            minlength: "The phone number should be 10 digits",
                            maxlength: "The phone number should be 10 digits",
                        },
                        select_industry: {
                            required: "Please select Industry",
                        },
                        select_solution: {
                            required: "Please select solution",
                        },
                        contact_message: {
                            required: "Please enter your message",
                        },
                    },
                    submitHandler: function(form) {
                        // sending value with ajax request
                        $('#submit').html('Submitting...');
                        var user_name = $("#contact_name").val();
                        var user_email = $("#contact_email").val();
                        var user_phone = $("#contact_phone").val();
                        var user_industry = $("#select_industry").val();
                        var user_solution = $("#select_solution").val();
                        var user_message = $("#contact_message").val();

                        var formDatanew = new FormData();
                        formDatanew.append("contact_name", user_name);
                        formDatanew.append("contact_email", user_email);
                        formDatanew.append("contact_phone", user_phone);
                        formDatanew.append("select_industry", user_industry);
                        formDatanew.append("select_solution", user_solution);
                        formDatanew.append("contact_message", user_message);
                        $.ajax({
                            url: 'formvendor/process.php',
                            type: "POST",
                            data: formDatanew,
                            contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
                            processData: false,
                            success: function(data) {
                                $("form").trigger("reset");
                                $('#submit').html('Submit Now');
                                $('#success').fadeIn().html(data);
                                setTimeout(function() {
                                    $('#success').fadeOut("Slow");
                                }, 5000);
                            }
                        });
                        return false;
                    },
                });
            }
        },

        careerFo: function() {
            var careerForm = $('#career-form');
            if (careerForm.length) {
                careerForm.validate({
                    // initialize the plugin
                    rules: {
                        career_name: {
                            required: true,
                        },
                        career_email: {
                            required: true,
                            email: true,
                        },
                        career_phone: {
                            required: true,
                            digits: true,
                            minlength: 10,
                            maxlength: 10,
                        },
                        career_location: {
                            required: true,
                        },
                        job_type: {
                            required: true,
                        },
                        job_profile: {
                            required: true,
                        },
                        resume: {
                            required: true,
                        },
                    },
                    messages: {
                        career_name: {
                            required: "Please enter your name",
                        },
                        career_email: {
                            required: "Please enter your email",
                            email: "Please enter valid email",
                        },
                        career_phone: {
                            required: "Please enter your contact",
                            digits: "Please enter only numbers",
                            minlength: "The phone number should be 10 digits",
                            maxlength: "The phone number should be 10 digits",
                        },
                        career_location: {
                            required: "Please enter location",
                        },
                        job_type: {
                            required: "Please select Job Type",
                        },
                        job_profile: {
                            required: "Please select Job Profile",
                        },
                        resume: {
                            required: "Please upload resume",
                        },
                    },
                    submitHandler: function(form) {
                        // sending value with ajax request
                        $('#carsubmit').html('Submitting...');
                        var user_name = $("#career_name").val();
                        var user_email = $("#career_email").val();
                        var user_phone = $("#career_phone").val();
                        var user_location = $("#career_location").val();
                        var user_jobtype = $("#job_type").val();
                        var user_profile = $("#job_profile").val();
                        var resume = $("#resume").val();
                        var rfileName = resume.replace(/C:\\fakepath\\/i, '');

                        var formDatanew = new FormData();
                        formDatanew.append("career_name", user_name);
                        formDatanew.append("career_email", user_email);
                        formDatanew.append("career_phone", user_phone);
                        formDatanew.append("career_location", user_location);
                        formDatanew.append("job_type", user_jobtype);
                        formDatanew.append("job_profile", user_profile);
                        formDatanew.append('rfile', $('#resume')[0].files[0]);
                        formDatanew.append("selResume", rfileName);
                        formDatanew.append("upload", "Yes");
                        $.ajax({
                            url: 'formvendor/careerprocess.php',
                            type: "POST",
                            data: formDatanew,
                            contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
                            processData: false,
                            success: function(data) {
                                $("form").trigger("reset");
                                $('#carsubmit').html('Submit Now');
                                $('#success').fadeIn().html(data);
                                setTimeout(function() {
                                    $('#success').fadeOut("Slow");
                                }, 5000);
                            }
                        });
                        return false;
                    },
                });
            }
        },

        featherAtcivation: function() {
            feather.replace()
        },

        wowActive: function() {
            new WOW().init();
        },


        counterupActive: function() {
            $('.counter').counterUp({
                delay: 10,
                time: 1000
            });
        },

        videoActivation: function() {
            $('.play__btn').yu2fvl();
        },

        slickActivation: function() {
            function slickactivation() {
                // Check if element exists
                $.fn.elExists = function() {
                    return this.length > 0;
                };
                // Variables
                var $html = $('html'),
                    $elementCarousel = $('.rn-slick-activation');
                if ($elementCarousel.elExists()) {
                    var slickInstances = [];
                    $elementCarousel.each(function(index, element) {
                        var $this = $(this);
                        // Carousel Options
                        var $options = typeof $this.data('slick-options') !== 'undefined' ? $this.data('slick-options') : '';
                        var $spaceBetween = $options.spaceBetween ? parseInt($options.spaceBetween) : 0,
                            $spaceBetween_xl = $options.spaceBetween_xl ? parseInt($options.spaceBetween_xl) : 0,
                            $isCustomArrow = $options.isCustomArrow ? $options.isCustomArrow : false,
                            $customPrev = $isCustomArrow === true ? ($options.customPrev ? $options.customPrev : '') : '',
                            $customNext = $isCustomArrow === true ? ($options.customNext ? $options.customNext : '') : '',
                            $vertical = $options.vertical ? $options.vertical : false,
                            $focusOnSelect = $options.focusOnSelect ? $options.focusOnSelect : false,
                            $asNavFor = $options.asNavFor ? $options.asNavFor : '',
                            $fade = $options.fade ? $options.fade : false,
                            $autoplay = $options.autoplay ? $options.autoplay : false,
                            $autoplaySpeed = $options.autoplaySpeed ? $options.autoplaySpeed : 5000,
                            $swipe = $options.swipe ? $options.swipe : false,
                            $adaptiveHeight = $options.adaptiveHeight ? $options.adaptiveHeight : false,

                            $arrows = $options.arrows ? $options.arrows : false,
                            $dots = $options.dots ? $options.dots : false,
                            $infinite = $options.infinite ? $options.infinite : false,
                            $centerMode = $options.centerMode ? $options.centerMode : false,
                            $centerPadding = $options.centerPadding ? $options.centerPadding : '',
                            $speed = $options.speed ? parseInt($options.speed) : 1000,
                            $prevArrow = $arrows === true ? ($options.prevArrow ? '<span class="' + $options.prevArrow.buttonClass + '"><i class="' + $options.prevArrow.iconClass + '"></i></span>' : '<button class="slick-prev">previous</span>') : '',
                            $nextArrow = $arrows === true ? ($options.nextArrow ? '<span class="' + $options.nextArrow.buttonClass + '"><i class="' + $options.nextArrow.iconClass + '"></i></span>' : '<button class="slick-next">next</span>') : '',
                            $slidesToShow = $options.slidesToShow ? parseInt($options.slidesToShow, 10) : 1,
                            $slidesToScroll = $options.slidesToScroll ? parseInt($options.slidesToScroll, 10) : 1;

                        /*Responsive Variable, Array & Loops*/
                        var $responsiveSetting = typeof $this.data('slick-responsive') !== 'undefined' ? $this.data('slick-responsive') : '',
                            $responsiveSettingLength = $responsiveSetting.length,
                            $responsiveArray = [];
                        for (var i = 0; i < $responsiveSettingLength; i++) {
                            $responsiveArray[i] = $responsiveSetting[i];

                        }

                        // Adding Class to instances
                        $this.addClass('slick-carousel-' + index);
                        $this.parent().find('.slick-dots').addClass('dots-' + index);
                        $this.parent().find('.slick-btn').addClass('btn-' + index);

                        if ($spaceBetween != 0) {
                            $this.addClass('slick-gutter-' + $spaceBetween);
                        }
                        if ($spaceBetween_xl != 0) {
                            $this.addClass('slick-gutter-xl-' + $spaceBetween_xl);
                        }
                        $this.slick({
                            slidesToShow: $slidesToShow,
                            slidesToScroll: $slidesToScroll,
                            asNavFor: $asNavFor,
                            autoplay: $autoplay,
                            autoplaySpeed: $autoplaySpeed,
                            speed: $speed,
                            infinite: $infinite,
                            arrows: $arrows,
                            dots: $dots,
                            vertical: $vertical,
                            focusOnSelect: $focusOnSelect,
                            centerMode: $centerMode,
                            centerPadding: $centerPadding,
                            fade: $fade,
                            adaptiveHeight: $adaptiveHeight,
                            prevArrow: $prevArrow,
                            nextArrow: $nextArrow,
                            responsive: $responsiveArray,
                        });

                        if ($isCustomArrow === true) {
                            $($customPrev).on('click', function() {
                                $this.slick('slickPrev');
                            });
                            $($customNext).on('click', function() {
                                $this.slick('slickNext');
                            });
                        }
                    });

                    // Updating the sliders in tab
                    $('a[data-toggle="tab"]').on('shown.bs.tab', function(e) {
                        $elementCarousel.slick('setPosition');
                    });
                }
            }
            slickactivation()
        },

        mesonaryActivation: function() {
            $('.rn-masonary-wrapper').imagesLoaded(function() {
                // filter items on button click
                $('.messonry-button').on('click', 'button', function() {
                    var filterValue = $(this).attr('data-filter');
                    $grid.isotope({
                        filter: filterValue
                    });
                });
                // init Isotope
                var $grid = $('.mesonry-list').isotope({
                    itemSelector: '.masonry_item',
                    percentPosition: true,
                    transitionDuration: '0.7s',
                    layoutMode: 'fitRows',
                    masonry: {
                        // use outer width of grid-sizer for columnWidth
                        columnWidth: 1,
                    }
                });
            });
            $('.messonry-button button').on('click', function(event) {
                $(this).siblings('.is-checked').removeClass('is-checked');
                $(this).addClass('is-checked');
                event.preventDefault();
            });
        },

        lightboxActivation: function() {
            lightGallery(document.getElementById('animated-thumbnials'), {
                thumbnail: true,
                animateThumb: false,
                showThumbByDefault: false
            });

            lightGallery(document.getElementById('lightgallery'));
            lightGallery(document.getElementById('lightgallerynew'));
        },

        mobileMenuActive: function(e) {
            $('.rn-popup-mobile-menu .nav-pills .nav-link').on('click', function(e) {
                $('.rn-popup-mobile-menu').removeClass('menu-open');
                $('html').css({
                    overflow: ""
                })
            })
            $('.rn-popup-mobile-menu .has-dropdown > a').on('click', function(e) {
                e.preventDefault();
                $(this).siblings('.submenu').toggleClass('active').slideToggle('400');
                $(this).toggleClass('open');
                $('html').css({
                    overflow: ""
                })
            });
            $('.humberger-menu').on('click', function(e) {
                e.preventDefault();
                $('.rn-popup-mobile-menu').addClass('menu-open');
                $('html').css({
                    overflow: "hidden"
                })
            });
            $('.close-menu').on('click', function(e) {
                e.preventDefault();
                $('.rn-popup-mobile-menu').removeClass('menu-open');
                $('.rn-popup-mobile-menu .has-dropdown > a').removeClass('open').siblings('.submenu').removeClass('active').slideUp('400');
                $('html').css({
                    overflow: ""
                })
            });
        },

        stickyHeader: function(e) {
            $(window).scroll(function() {
                if ($(this).scrollTop() > 250) {
                    $('.header--sticky').addClass('sticky')
                } else {
                    $('.header--sticky').removeClass('sticky')
                }
            })
        },

    }
    imJs.m();

    particlesJS('particles-js',

        {
            "particles": {
                "number": {
                    "value": 60,
                    "density": {
                        "enable": true,
                        "value_area": 800
                    }
                },
                "color": {
                    "value": ["#ffffff", "#FF011F", "#cc3333", "#FF011F"]
                },
                "shape": {
                    "type": "circle",
                    "stroke": {
                        "width": 0,
                        "color": "#000000"
                    },
                    "polygon": {
                        "nb_sides": 4
                    },
                    "image": {
                        "src": "img/github.svg",
                        "width": 100,
                        "height": 100
                    }
                },
                "opacity": {
                    "value": 0.5,
                    "random": false,
                    "anim": {
                        "enable": false,
                        "speed": 1,
                        "opacity_min": 0.1,
                        "sync": false
                    }
                },
                "size": {
                    "value": 4,
                    "random": true,
                    "anim": {
                        "enable": false,
                        "speed": 40,
                        "size_min": 0.1,
                        "sync": false
                    }
                },
                "line_linked": {
                    "enable": true,
                    "distance": 150,
                    "color": "#ffffff",
                    "opacity": 0.4,
                    "width": 1
                },
                "move": {
                    "enable": true,
                    "speed": 6,
                    "direction": "none",
                    "random": false,
                    "straight": false,
                    "out_mode": "out",
                    "attract": {
                        "enable": false,
                        "rotateX": 600,
                        "rotateY": 1200
                    }
                }
            },
            "interactivity": {
                "detect_on": "canvas",
                "events": {
                    "onhover": {
                        "enable": true,
                        "mode": "repulse"
                    },
                    "onclick": {
                        "enable": true,
                        "mode": "push"
                    },
                    "resize": true
                },
                "modes": {
                    "grab": {
                        "distance": 400,
                        "line_linked": {
                            "opacity": 1
                        }
                    },
                    "bubble": {
                        "distance": 800,
                        "size": 40,
                        "duration": 2,
                        "opacity": 8,
                        "speed": 3
                    },
                    "repulse": {
                        "distance": 200
                    },
                    "push": {
                        "particles_nb": 4
                    },
                    "remove": {
                        "particles_nb": 2
                    }
                }
            },
            "retina_detect": true,
            "config_demo": {
                "hide_card": false,
                "background_color": "#b61924",
                "background_image": "",
                "background_position": "50% 50%",
                "background_repeat": "no-repeat",
                "background_size": "cover"
            }
        }

    );

})(window, document, jQuery)